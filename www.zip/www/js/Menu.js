
var Menu = {

    preload : function() {
           game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
            game.scale.pageAlignHorizontally = true;
            game.scale.pageAlignVertically = true;
            game.stage.backgroundColor = 'blue'; 
        // Loading images is required so that later on we can create sprites based on the them.
        // The first argument is how our image will be refered to, 
        // the second one is the path to our file.
        game.load.image('a', 'img/a.png');
           game.load.image('play', 'img/play.png');
           

    },

    create: function () {
        // Add a sprite to your game, here the sprite will be the game's logo
        // Parameters are : X , Y , image name (see above) 
        this.add.sprite(0,0, 'a');
             this.add.button(340, 350, 'play', this.startGame, this);
    },

    startGame: function () {

        // Change the state to the actual game.
        this.state.start('Level1');

    }


};