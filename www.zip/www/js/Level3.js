var bounds = 2000;
var Level3 ={

preload: function () {
    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;
    game.stage.backgroundColor = 'blue';


    //game.load.image("bg1","img/aaaa.png");
    game.load.image("ground","img/bg10.png");
    game.load.spritesheet("character2","img/tao5.png", 30,47);
    game.load.image("block","img/block2.png");
    game.load.image("rbt","img/rbt.png");
    game.load.image("lbt","img/lbt.png");
    game.load.image("ubt","img/ubt.png");
    game.load.image("dbt","img/dbt.png");
    game.load.image("bb","img/b.png");
    game.load.image("portal","img/portal.png");
    game.load.image("portal1","img/portal1.png", process.start2);
    game.load.image("bunot","img/bunot2.png");
    game.load.audio("versace","audio/background.mp3");
    game.load.image('restart', 'img/restart.png');
    game.load.image("stop","img/stop.png",stop);
    game.load.image("3","img/3.png");
},


create: function () {
     
    game.physics.startSystem(Phaser.Physics.ARCADE);
    game.add.sprite(0,0,"ground");

    platforms = game.add.group();
            platforms.enableBody = true;
             var ground = platforms.create(0, game.world.height - 50, '');

    level = game.add.group();
            level.enableBody = true;
    // bg1 = game.add.tileSprite(0,
    //     (game.height-game.cache.getImage ("bg1").height)-0,
    //     game.width,
    //     game.cache.getImage("bg1").height,
    //     'bg1');
   

     
        bb = game.add.group();
        bb.enableBody = true;
        var ground = bb.create(0,200,  'bb');
        ground.scale.setTo(1, 1);
        ground.body.immovable = true;

    

    lbt =game.add.button(0,525, "lbt", process.walkLeft);
    lbt.scale.x =0.5;
    lbt.scale.y =0.5;
    lbt.fixedToCamera = true;

    rbt =game.add.button(730,472, "rbt", process.walkRight);
    rbt.scale.x =0.5;
    rbt.scale.y =0.5;
    rbt.fixedToCamera = true;

    ubt =game.add.button(40,470, "ubt", process.walkUp);
    ubt.scale.x =0.5;
    ubt.scale.y =0.5;
    ubt.fixedToCamera = true;

    dbt =game.add.button(680,525, "dbt", process.walkDown);
    dbt.scale.x =0.5;
    dbt.scale.y =0.5;
    dbt.fixedToCamera = true;

    restart = game.add.button(60,10,"restart", process.restart3);
    restart.fixedToCamera = true;

    stop =game.add.button(10,10, "stop", process.stop);
    stop.scale.setTo(1,1);
    stop.events.onInputUp.add(function(){
        stop.frame=1;
        game.paused =true;
        gamePauseText.text ="Tap to continue";
        gamePauseText.text.visible = true;
    }),
    game.input.onDown.add(unpause,self);
    function unpause (event){
        if (game.paused){
            game.paused = false;
        }
        stop.frame=0;
        gamePauseText.destroy();
        gamePauseText.text.visible=false;

    }
 mj = game.add.group();
            mj.enableBody = true;

    var image = mj.create(720,10,"portal");
            image.immovable=true;

    var ledge = level.create(730,10,"portal1", process.start2);
            ledge.immovable=true;
 text = game.add.image(300,10, "3");
            text.fixedToCamera = true;
    //stop: function (){
//     this.game.paused = true;
//     var gamePauseText = this.add.text(330,250,"Tap to continue", this);
//     this.input.onDown.add(function(){
//         gamePauseText.destroy();
//         this.game.paused = false;
//     },this);
    stop.fixedToCamera = true;

    
    versace = game.add.audio ("versace");

    versace.play();

     player= game.add.sprite (350,600,"character2");
      game.physics.arcade.enable(player);
    // player.body.bounce.y = 0.2;
    player.body.collideWorldBounds = true;
    player.body.gravity.y= 0;
    player.body.gravity.x=0;

   
    
    player.animations.add("walk-left", [4,5,6,7],7,true);
    player.animations.add("walk-right", [8,9,10,11],7,true);
    player.animations.add("walk-up", [12,13,14,15],7,true);
    player.animations.add("walk-down", [0,1,2,3],7,true);

     stars = game.add.group();
     stars.enableBody = true;
        var star = stars.create(360, 150, 'bunot');
        star.scale.x=0.5;
        star.scale.y=0.5;

         marks = game.add.group();
         marks.enableBody = true;
        var mark = marks.create(200, 280, 'block');
        mark.scale.x=0.5;
        mark.scale.y=0.5;
         var mark = marks.create(200, 160, 'block');
        mark.scale.x=0.5;
        mark.scale.y=0.5;
        var mark = marks.create(200, 380, 'block');
        mark.scale.x=0.5;
        mark.scale.y=0.5;
        var mark = marks.create(300, 380, 'block');
        mark.scale.x=0.5;
        mark.scale.y=0.5;
         var mark = marks.create(400, 380, 'block');
        mark.scale.x=0.5;
        mark.scale.y=0.5;
        var mark = marks.create(500, 380, 'block');
        mark.scale.x=0.5;
        mark.scale.y=0.5;
        var mark = marks.create(600, 380, 'block');
        mark.scale.x=0.5;
        mark.scale.y=0.5;
        var mark = marks.create(700, 380, 'block');
        mark.scale.x=0.5;
        mark.scale.y=0.5;
             

   

    keyboard = game.input.keyboard.createCursorKeys();

    
   

    scoreText = game.add.text(10, 60, "Score: 0", {fontSize: '35px Rockwell',fill: "darkblue",stroke:"pink", strokeThickness:6});
bestText = game.add.text(10,100, "Best: " + process.getData() ,{fontSize: '35px Rockwell',fill: "darkblue",stroke:"pink", strokeThickness:6});
gameOverText = game.add.text(w-500,250, "", {fill: "blue",stroke:"pink", strokeThickness:6});
gamePauseText = game.add.text(w-500,250, "", {fill: "blue",stroke:"pink", strokeThickness:6});
cursors = game.input.keyboard.createCursorKeys();
//game.camera.follow(player, Phaser.Camera.FOLLOW_TOPDOWN);
   
},

update: function () {
   
    game.physics.arcade.collide(player, platforms);
    game.physics.arcade.overlap (player,stars, process.collectStar, null,this);
    game.physics.arcade.overlap (player,marks, process.killMark, null,this);
    game.physics.arcade.overlap(player, level, process.start2, null, this);

      //  game.physics.arcade.overlap(player,bunot,process.killBunot);
    game.physics.arcade.overlap(player,block,process.killCharacter);
    game.physics.arcade.overlap(player,block,process.killBlock);
    
    // bg1.tilePosition.y +=0.3;

    player.body.velocity.x=0;
    
    if (player.body.velocity.x === 0 || player.body.velocity === 0){

}
else if (keyboard.right.isDown)
{
    player.body.velocity.x = 1000;
    player.animations.play('walk-right');
}
else
{
    player.animations.stop();
    player.frame = 0;
}
if (keyboard.up.isDown && player.body.touching.down)
{
    player.body.velocity.y = -1000;
}
  
}
}
game.state.add("Level3", Level3,false);



