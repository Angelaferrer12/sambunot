var process = function(){
    "use strict";
    return{
createGhost: function(time){
       setInterval(function(){
        for (var c = 0; c < 1; c++)
        {
        ghosts = ghost.create(Math.random() *0, 700, "ghost");
        ghosts.body.gravity.x = 1500;
        ghost.scale.x = 0.5;
        ghost.scale.y = 0.5;
    }

    },time);
},
 
// 
killGhost:function (player, ghost) {
    ghost.kill();
    soundeffect.play();

    gameOverText.text = "GAME OVER\nBest: "+process.getData() +"\nScore: "+score;
     setTimeout(function(){
       // btn.frame = 0
        game._paused = false;
    }, 5000)
    game._paused = true;

   
},


createStars : function(time) {
    setInterval(function() {
        bunots= bunot.create(Math.random()*900, -100, "bunot");
        bunots.body.gravity.y = 60;
 

        bunots.body.collideWorldBounds = true;
    },time);
}, 
collectStar : function(player, bunot) {
    
   score= score + 5;
    bunot.kill();
    // soundeffect.play();

    
    if (process.getData()<+score){
        process.saveData(score);
        bestText.text ="Best:" + score;
        console.log("galing!");
    }

    else {
        console.log ("di mo nareach!");
    }
    scoreText.text = "Score:" + score;
},
createMarks : function(time) {
    setInterval(function() {
        marks= mark.create(Math.random()*900, -100, "block");
        marks.body.gravity.y = 60;
 

        marks.body.collideWorldBounds = true;
    },time);
}, 
 killMark:function (player, block) {
    block.kill();
    soundeffect.play();

    gameOverText.text = "GAME OVER\nBest: "+process.getData() +"\nScore: "+score;
     setTimeout(function(){
       // btn.frame = 0
        game._paused = false;
    }, 5000)
    game._paused = true;
    background.stop();
   
},
 
 
saveData: function(score){
        localStorage.setItem("gameData",score);
    },
getData: function(){
        return (localStorage.getItem("gameData") == null|| localStorage.getItem("gameData") == "")? 0: localStorage.getItem("gameData",bestText);
    },

walkRight: function(){
        player.animations.play('walk-right');
        player.body.velocity.x = 5000;

    },
walkLeft:function(){
       player.animations.play('walk-left');
        player.body.velocity.x = -5000;
    },
walkUp:function(){
        player.body.velocity.y = -300;
            player.animations.play('walk-up');
        //btnUp.frame = 1;
    },
walkDown:function(){
        player.body.velocity.y =300;
            player.animations.play('walk-down');
        // btnDown.frame = 1;
    },
    // stop: function (){
    //     this.game.paused = true;
    //     var gamePauseText = this.add.text(330,250,"Tap to continue", this);
    //     this.input.onDown.add(function(){
    //         gamePauseText.destroy();
    //         this.game.paused = false;
    //     },this);
    // },
       
start : function(){
    game.state.start("Level2");
    console.log("x");
    },
    
    start1 : function(){
    game.state.start("Level3");
    console.log("y");
    },

      start2 : function(){
    game.state.start("Level4");
    console.log("x");
    },

       start3 : function(){
    game.state.start("Level5");
    console.log("x");
    },
        start4 : function(){
    game.state.start("Level6");
    console.log("x");
    },

          start5 : function(){
    game.state.start("Level7");
    console.log("x");
    },
    
           start6 : function(){
    game.state.start("Level8");
    console.log("x");
    },

             
restart : function (){
        game.state.start("Level1");
        // background.play();
        soundeffect.stop();
    },
      restart2 : function (){
        game.state.start("Level2");
        soundeffect.stop();
    },
      restart3 : function (){
        game.state.start("Level3");
        soundeffect.stop();
    },
      restart4 : function (){
        game.state.start("Level4");
        soundeffect.stop();
    },
      restart5 : function (){
        game.state.start("Level5");
        soundeffect.stop();
    },
     restart6 : function (){
        game.state.start("Level6");
        soundeffect.stop();
    },
      restart7 : function (){
        game.state.start("Level7");
        soundeffect.stop();
    },
      restart8 : function (){
        game.state.start("Level8");
        soundeffect.stop();
    },
      

audio: function(time){
        setInterval(function(){
            background.play();
        },time )
    }
}
}();