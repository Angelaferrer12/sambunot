ar w = 800, h = 600;
var score= 0;
var player, keyboard;
var  scoreText, gameOverText, bestText, ground,  gamePauseText,
 versace,rbt,lbt,ubt,dbt,bunot,bunots,bb,block,blocks, ghost,ghosts,stop, restart,bg1;
var game = new Phaser.Game(w, h, Phaser.CANVAS, '');

game.state.add("Menu", Menu);


game.state.start("Menu");

game.state.add('Level1');
