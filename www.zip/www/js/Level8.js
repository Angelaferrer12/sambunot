var bounds = 2000;
var Level8 ={

preload: function () {
    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;
    game.stage.backgroundColor = 'blue';


    //game.load.image("bg1","img/aaaa.png");
    game.load.image("end","img/end.png");
    
},


create: function () {
     
    game.physics.startSystem(Phaser.Physics.ARCADE);

    game.add.sprite(0,0,"end");

     
       
    

   
},

update: function () {
   
   
  
}
}
game.state.add("Level8", Level8,false);



