var w = 800, h = 600;
var score= 0;
var player, keyboard;
var  scoreText, gameOverText, bestText, ground,  gamePauseText,
 versace,rbt,lbt,ubt,dbt,bunot,bunots,ghost,ghosts,bb,block,blocks, stop, restart,bg1,background,soundeffect;
var game = new Phaser.Game(w, h, Phaser.CANVAS, '');

game.state.add("Menu", Menu);


game.state.start("Menu");

game.state.add('Level1');
game.state.add('Level2');
game.state.add('Level3');
game.state.add('Level4');
game.state.add('Level5');
game.state.add('Level6');
game.state.add('Level7');
game.state.add('Level8');

